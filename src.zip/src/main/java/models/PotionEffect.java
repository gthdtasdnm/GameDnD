package models;

public enum PotionEffect {
    HEAL
}
