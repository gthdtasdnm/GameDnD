package models;

public enum EquipmentSlot {
    HEAD,
    CHEST,
    LEGS,
    FEET,
    ARMS,
    WEAPON,
    SHIELD
}
