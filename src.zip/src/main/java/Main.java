

import state.GameManager;

public class Main {
   public static void main(String[] args) {
        GameManager game = new GameManager();
        game.startGame();
    }
}

