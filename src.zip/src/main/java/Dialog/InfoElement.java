package Dialog;

public interface InfoElement {
    void execute();
}
