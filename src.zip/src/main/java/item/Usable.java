package item;

public interface Usable {
    void use(Character character);
}
